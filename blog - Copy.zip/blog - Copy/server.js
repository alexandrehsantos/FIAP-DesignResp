const bodyParser= require('body-parser');
const fs = require('fs');
const dbfolder = __dirname + '/db';
const contatosDbPath = dbfolder + '/contatos.json';
const path = require('path'); 

const express = require('express');
var app = express();


if(!fs.existsSync(dbfolder)){
    fs.mkdirSync(dbfolder);
}


var tryRead = function (path, callback){
    fs.readFile(path, 'utf8', function (err, contatos){
        if (err) return callback([]);
        var contatosJSON =[];
        try{
            contatosJSON = JSON.parse(contatos);
        }catch (error){}
        return callback(contatosJSON);
    });
}

app.use(express.static(path.join(__dirname, 'dist')));
app.get('*', function (req, res){

    res.status(404).send({ error: 'API not found'});
});

app.listen(process.env.POR || 3000, function(){
    console.log('escutando na porta 3000');
});

app.use(bodyParser.urlencoded({ extended: true}));
app.use(bodyParser.json());

app.post('/api/contato', function(req,res){
    tryRead(contatosDbPath,function (contatos) {
        contatos.push(req.body);
fs.writeFile(contatosDbPath, JSON.stringify(contatos), function(err){
    if(err){
        res.status(500).json( { error: 'Opa, detectamos um problema! Tente novamente mais tarde!'});
        return;
    }

    res.status(200).json({ sucess: true});
});       
});
});

app.get('api/artigos', function(req, res){
    const artigosDbPath = dbfolder + '/artigos.json';
        tryRead(artigosDbPath, function(artigos){
            res.status(200).json(artigos);
        });
});






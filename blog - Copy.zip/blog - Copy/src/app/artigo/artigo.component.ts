import { Component, OnInit, NgZone } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { Artigo } from '../home/home.component';
import {Http, Response, RequestOptions, Headers} from '@angular/http';
import * as jQuery from 'jquery';
import 'rxjs/add/operator/map';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-artigo',
  templateUrl: './artigo.component.html',
  styleUrls: ['./artigo.component.css']
})
export class ArtigoComponent implements OnInit {
  public html: any = " ";
  artigo = new Artigo();
  
  constructor(private activateRoute: ActivatedRoute, private http: Http,
  private zone: NgZone, private sanitizer: DomSanitizer){

  }

  ngOnInit() {
    this.activateRoute.params.subscribe(params => {
      let id = params['id'];
      this.http.get('api/artigo' + id)
      .subscribe(artigo => {
        this.zone.run(() => {
          this.resultadoArtigo(artigo);
        });
      });
      });
}

resultadoArtigo(file){
  this.html = this.sanitizer.bypassSecurityTrustHtml(file._body);
}

}
